import lagrange

import MDAOfabric
from MDAOfabric import mpi_world
from .solver_base import SolverBase

# change dir for Lagrange?
# input only as solver?


class LagrangeStructuralSolver(SolverBase):

    def __init__(self, settings):

        if not mpi_world.IsRoot():
            return
        super(LagrangeStructuralSolver, self).__init__(settings)

        # initialize external solver
        MDAOfabric.log.info('Initialising Lagrange solver...')
        lagrange.init(self.settings["lagrange_message_path"])  # TODO: format of settings and input file (below)?
        self._lagrange_api = lagrange.Lagrange(self.settings["input_file"])

    def GetDefaultSettings(self):
        default_settings = ('''{
                            "type"                  : "LagrangeStructuralSolver",
                            "name"                  : "LagrangeStructuralSolver_unnamed",
                            "input_file"            : ">required<",
                            "lagrange_message_path" : "lagrange_messages.txt",
                            "pass_to_lagrange"      : "tbd",
                            "interface"             : "tbd"
                        }''')
        return MDAOfabric.Settings.FromString(default_settings)

    def Initialize(self):
        if not mpi_world.IsRoot():
            return

        self._lagrange_api.preproc()

    def Run(self):
        if not mpi_world.IsRoot():
            return

    def Finalize(self):
        if not mpi_world.IsRoot():
            return

    def GetInterface(self):
        # TODO get this as reference?

        interface_mesh = dict()
        interface_mesh["nnode"], interface_mesh["nelem"], interface_mesh["nodes"], \
            interface_mesh["inode"], _, interface_mesh["elems"], interface_mesh["ielem"] = \
            self.api.get_mesh_ext_id_from_set(self.settings["interface"])

        return interface_mesh
