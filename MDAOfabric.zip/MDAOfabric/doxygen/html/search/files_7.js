var searchData=
[
  ['logger_2epy',['logger.py',['../logger_8py.html',1,'']]]
];
