var searchData=
[
  ['validateandassigndefaults',['ValidateAndAssignDefaults',['../class_m_d_a_ofabric_1_1accessories_1_1settings_1_1_settings.html#a9d0da02aaaf153568b98253eabf0173a',1,'MDAOfabric::accessories::settings::Settings']]]
];
