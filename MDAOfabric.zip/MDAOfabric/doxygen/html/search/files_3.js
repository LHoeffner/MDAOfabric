var searchData=
[
  ['empty_5fsolver_2epy',['empty_solver.py',['../empty__solver_8py.html',1,'']]],
  ['empty_5fsolver_5ftests_2epy',['empty_solver_tests.py',['../empty__solver__tests_8py.html',1,'']]]
];
