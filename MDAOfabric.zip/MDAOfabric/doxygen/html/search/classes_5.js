var searchData=
[
  ['logger',['Logger',['../class_m_d_a_ofabric_1_1accessories_1_1logger_1_1_logger.html',1,'MDAOfabric::accessories::logger']]]
];
