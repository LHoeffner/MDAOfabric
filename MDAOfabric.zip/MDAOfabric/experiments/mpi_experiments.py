import mpi4py.futures
from mpi4py import MPI

communicator = MPI.COMM_WORLD
print("outside rank:", communicator.Get_rank())
def work(string):
    res = 1
    print(MPI.Status())
    print('rank here:', communicator.Get_rank())
    for i in range(100):
        res *= i+1
    return string+"-"

if __name__ == '__main__':
    print('MPI host:', MPI.Get_processor_name())
    print("communicator.size:", communicator.Get_size())

    work("should be a minus: ")

    list_a = ["A", "B", "C", "D", "E"]

    print('\n\npool gets going')
    with mpi4py.futures.MPIPoolExecutor(max_workers=2) as executor:
        for result in executor.map(work, list_a):
            print(result)


