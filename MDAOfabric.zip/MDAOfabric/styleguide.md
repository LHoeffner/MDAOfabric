# guide to MDAOfabric code style 

### naming, spacing, layout:
**general rule:** follow the [PEP8 style](pep8.org), most importantly:

* capital class names, lower case members (objects in general)
* indentation uses four spaces, one blank line between function definitions and two before and after class definitions

**exceptions:**

* *[missing Alessandro's approval]* capitalised function names, written as: *DoSomething()* (reason: this provides am more clear distinction between objects and functions when class members are called from outside e.g. *SomeClass.DoSomething()* vs. *SomeClass.member_obj*)
***


### logs, messages, exceptions:

* logs and prints should always use the fabric's own *Logger* class
* *[missing Alessandro's approval]* always use a meaningful exception type from the ones provided in the fabric's accessories (not the default *Exception*)
***


### others:

* Python version 3.7 can be expected, compatibility for earlier versions is not a goal in the fabric's development
* use type hints (as introduced with Python 3.5) wherever possible 